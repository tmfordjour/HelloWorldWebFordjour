﻿using System.Collections.Generic;
namespace HelloWorldWebFordjour.Models
{
    public class StudentListViewModel
    {
        public List<Student> Students { get; set; }
        public int AccessLevel { get; set; }
    }
}
